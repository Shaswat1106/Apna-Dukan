// Scroll to Service Section
document.querySelector(".cta-btn").addEventListener("click", function() {
    document.getElementById("services").scrollIntoView({
        behavior: "smooth"
    });
});

// Contact Form Submission
document.querySelector('.contact form').addEventListener('submit', function(e) {
    e.preventDefault(); // Prevent page reload
    alert('Your message has been sent!');
});

// Handle the booking form submission
document.getElementById('bookingForm').addEventListener('submit', function(e) {
    e.preventDefault();

    // Capture form data
    const name = e.target.name.value;
    const phone = e.target.phone.value;
    const date = e.target.date.value;
    const address = e.target.address.value;

    // Here you could send the booking information to the server for processing
    // For now, just logging the data
    console.log('Booking Information:', { name, phone, date, address });

    // Display a confirmation message (or redirect to a confirmation page)
    alert('Your booking is confirmed! A plumber will be with you soon.');

    // Optionally, reset the form
    e.target.reset();
});
